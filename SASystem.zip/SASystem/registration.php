<?php 
session_start(); 
require 'connect.php';
require 'functions.php';
if(isset($_POST['stu_name'])) 
{	 
    $qury1 = "SELECT MAX(app_id) FROM student_registration";
	$result1 = mysqli_query($con, $qury1);
	while($row = mysqli_fetch_array($result1)):;
	echo $appl = $row[0];
	endwhile;
	$year = date('Y');
	if($appl == null)
	{
		$app_no = $year.'00001';
	}
	else
	{
		$arr = explode("/",$appl);
		$code = $arr[1];
		$prefix = $year.'/';
		$sufix = str_pad($code+1,5,0,STR_PAD_LEFT);
		$app_no = str_pad($sufix,10,$prefix,STR_PAD_LEFT);
	}
	$admission = clean($_POST['coursefor']);
	if($admission == 'M.sc')
	{
		$cou = '01';
	}
	else if($admission == 'M.phil')
	{
		$cou = '02';
	}
	$qury2 = "SELECT MAX(student_id) FROM student_registration";
	$result2 = mysqli_query($con, $qury2);
	while($row2 = mysqli_fetch_array($result2)):;
	$stu = $row2[0];
	endwhile;
	$year = date('Y');
	if($stu == null)
	{
		$student_id = $year.'/'.$cou.'/00001';
	}
	else
	{
		$arr1 = explode("/",$stu);
		$code1 = $arr1[2];
		$prefix = $year.'/'.$cou.'/';
		$sufix = str_pad($code1+1,5,0,STR_PAD_LEFT);
		$student_id = str_pad($sufix,13,$prefix,STR_PAD_LEFT);
	}
    $app_date = date('Y-m-d'); 
	$stu_name = clean($_POST['stu_name']); 
    $stu_name_t = clean($_POST['stu_name_t']); 
    $gen = clean($_POST['gender']); 
    $dob = clean($_POST['dob']); 
	$religion = clean($_POST['religion']); 
	$community= clean($_POST['community']);
	$native_state = clean($_POST['native_state']);
	$nationality = clean($_POST['nationality']);
	$blood_grup = clean($_POST['blood_grp']);
	$cur_add = clean($_POST['cur_add']);
	$per_add = clean($_POST['per_add']);
	$mobile = clean($_POST['mobile']);
	$email = clean($_POST['email']);
	$person_of = clean($_POST['person_of']);
	$yrs_of_study = clean($_POST['yrs_of_study']);
	$qual_xm_pssd = clean($_POST['qual_xm_pssd']);
	$qual = clean($_POST['qual']);
	$subj = clean($_POST['subj']);
	$reg_no = clean($_POST['reg_no']);
	$mon_yr_pass = clean($_POST['mon_yr_pass']);
	$stu_type = clean($_POST['stu_type']);
	$dept = clean($_POST['dept']);
	$action_status = '11';
	$state = 'P';
	$query = "SELECT * FROM student_registration WHERE reg_no = '$stu_name'";
    $result = mysqli_query($con,$query); 
    if(mysqli_num_rows($result) == null) 
	{
		$query_insert = "INSERT INTO student_registration (student_id,app_id,appl_date,stu_name,stu_name_t,gender_code,dob,community_code,religion_code,nationality,
		native_state,blood_grup,cur_address,per_address,mobile_no,email_id,person_of,dept,years_of_study,qualification,qual_xm_pass,
		subject,reg_no,mon_year_pass,student_type,action_status,state,admission_for) VALUES ('$student_id','$app_no','$app_date','$stu_name','$stu_name_t','$gen','$dob','$community','$religion','$nationality',
		'$native_state','$blood_grp','$cur_add','$per_add','$mobile','$email','$person_of','$dept','$yrs_of_study','$qual','$qual_xm_pssd',
		'$subj','$reg_no','$mon_yr_pass','$stu_type','$action_status','$state','$admission')";
        $login_insert = "INSERT INTO student_login (student_id,password,username) VALUES ('$student_id','$stu_name','$stu_name')";
		if(mysqli_query($con, $query_insert) && mysqli_query($con, $login_insert)) 
		{
			$_SESSION['prompt'] = "Application Form Submitted.You can edit before dd/mm/yyyy";
			header("location:login_form.php");
			exit;
        } 	
		else 
		{
			//die("Error with the query");
			header("location:login_form.php");
        }
	}
	else
	{
		$_SESSION['errprompt'] = "Register Number Already Exit";
        header("location:registration_form.php");
        exit;
	}
}	
?>
