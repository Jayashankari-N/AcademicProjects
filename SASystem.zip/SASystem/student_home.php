<?php 
  require 'connect.php';
  require 'functions.php';
  session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Profile - Student Admission System</title>
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/css/main.css" rel="stylesheet">
	<style>
	.entry_table
	{
		margin-left:30px;
		width:1300px;
		height:70px;
		border: 1px solid black;
		}
	</style>
</head>
<body>
    <?php include 'header1.php'; ?>
	<script src="assets/js/jquery-3.1.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/main.js"></script>
	
	<div style="height:100px;">
	<form action="<?php echo "addmark.php";?>" method="post" id="add_mark">
    <table class="entry_table">
      <tr style="border=1px;">
       <td><label style="width:150px;margin-left:5px;">Semester</label></td>
       <td><label style="width:120px;margin-left:5px;">Subject Code</label></td>
       <td><label style="width:180px;margin-left:5px;">Paper Name</label></td>
       <td><label style="width:100px;margin-left:5px;">Credits</label></td>
       <td><label style="width:100px;margin-left:5px;">IA</label></td>
       <td><label style="width:100px;margin-left:5px;">UE</label></td>
       <td><label style="width:100px;margin-left:5px;">Total</label></td>
       <td><label style="width:100px;margin-left:5px;">Grade Points</label></td>
       <td><label style="width:100px;margin-left:5px;">Grade</label></td>
       <td><label style="width:88px;margin-left:5px;">Action</label></td>
      </tr>
	  <?php 
	  $id = $_SESSION['userid'];
	  if(isset($_GET['id']))
	  {
		  $slno = $_GET['id'];
		$qury2 = "SELECT * FROM student_mark_list WHERE student_id = '$id' and slno = '$slno'";
		$result2 = mysqli_query($con, $qury2);
		while($row2 = mysqli_fetch_array($result2)):;
	   ?>
	   <tr style="border=1px;">
       <td><select name="sem" id="sem" style="width:150px;margin-left:5px;" class="form-control">
      <option value="0">Select Semester</option>
	  <option value="I Semester" <?php if($row2[2] == 'I Semester'){?>selected="true"<?php }?>>I Semester</option>
	  <option value="II Semester" <?php if($row2[2] == 'II Semester'){?>selected="true"<?php }?>>II Semester</option>
	  <option value="III Semester" <?php if($row2[2] == 'III Semester'){?>selected="true"<?php }?>>III Semester</option>
	  <option value="IV Semester" <?php if($row2[2] == 'IV Semester'){?>selected="true"<?php }?>>IV Semester</option>
	  <option value="V Semester" <?php if($row2[2] == 'V Semester'){?>selected="true"<?php }?>>V Semester</option>
	  <option value="VI Semester" <?php if($row2[2] == 'VI Semester'){?>selected="true"<?php }?>>VI Semester</option>
	  <option value="VII Semester" <?php if($row2[2] == 'VII Semester'){?>selected="true"<?php }?>>VII Semester</option>
	  <option value="VIII Semester" <?php if($row2[2] == 'VIII Semester'){?>selected="true"<?php }?>>VIII Semester</option>
	  <option value="IX Semester" <?php if($row2[2] == 'XI Semester'){?>selected="true"<?php }?>>IX Semester</option>
	  <option value="X Semester" <?php if($row2[2] == 'X Semester'){?>selected="true"<?php }?>>X Semester</option>
     </select></td>
       <td><input type="text" name = "sub_code" style="width:120px;margin-left:5px;" class="form-control" value="<?php echo $row2[3];?>"/></td>
       <td><input type="text" name = "sub_name" style="width:180px;margin-left:5px;" class="form-control" value="<?php echo $row2[4];?>"/></td>
       <td><input type="text" name = "credit" style="width:100px;margin-left:5px;" class="form-control" value="<?php echo $row2[5];?>"/></td>
       <td><input type="text" name = "im" style="width:100px;margin-left:5px;" class="form-control" value="<?php echo $row2[6];?>"/></td>
       <td><input type="text" name = "em" style="width:100px;margin-left:5px;" class="form-control" value="<?php echo $row2[7];?>"/></td>
       <td><input type="text" name = "total" style="width:100px;margin-left:5px;" class="form-control" value="<?php echo $row2[10];?>"/></td>
       <td><input type="text" name = "grade_pts" style="width:100px;margin-left:5px;" class="form-control" value="<?php echo $row2[8];?>"/></td>
       <td><input type="text" name = "grade" style="width:100px;margin-left:5px;" class="form-control" value="<?php echo $row2[9];?>"/></td>
       <td><input type="hidden" name="slno" value="<?php echo $row2[1]; ?>"><input type="submit" value="update" style="width:88px;margin-left:5px; background-color:green; color:white;" name="updatemark" class="form-control"/></td>
      </tr>
	  <?php
		endwhile;
	  }
	  else
	  {?>
	<tr style="border=1px;">
       <td><select name="sem" id="sem" style="width:150px;margin-left:5px;" class="form-control">
      <option value="0">Select Semester</option>
	  <option value="I Semester">I Semester</option>
	  <option value="II Semester">II Semester</option>
	  <option value="III Semester">III Semester</option>
	  <option value="IV Semester">IV Semester</option>
	  <option value="V Semester">V Semester</option>
	  <option value="VI Semester">VI Semester</option>
	  <option value="VII Semester">VII Semester</option>
	  <option value="VIII Semester">VIII Semester</option>
	  <option value="IX Semester">IX Semester</option>
	  <option value="X Semester">X Semester</option>
     </select></td>
       <td><input type="text" name = "sub_code" id = "sub_code" style="width:120px;margin-left:5px;" class="form-control" placeholder="Subject Code"/></td>
       <td><input type="text" name = "sub_name" style="width:180px;margin-left:5px;" class="form-control" placeholder="Paper Name"/></td>
       <td><input type="text" name = "credit" style="width:100px;margin-left:5px;" class="form-control" placeholder="Credits"/></td>
       <td><input type="text" name = "im" style="width:100px;margin-left:5px;" class="form-control" placeholder="IA" maxlength="2"/></td>
       <td><input type="text" name = "em" style="width:100px;margin-left:5px;" class="form-control" placeholder="UE" maxlength="2"/></td>
       <td><input type="text" name = "total" id="total" style="width:100px;margin-left:5px;" class="form-control" placeholder="Total" onblur="chkmrk(this);" maxlength="3" autocomplete="off" value=""/></td>
       <td><input type="text" name = "grade_pts" style="width:100px;margin-left:5px;" class="form-control" placeholder="Grade Points"/></td>
       <td><input type="text" name = "grade" style="width:100px;margin-left:5px;" class="form-control" placeholder="Grade"/></td>
       <td><input type="submit" value="Add" style="width:88px;margin-left:5px; background-color:green; color:white;" name="addmark" class="form-control"/></td>
      </tr>
	  <?php }
	  ?>
    </table>
	</form>
   </div>
   <?php if(isset($_GET['id']))
	  {?>
	<div>
		<center><a href="<?php echo "student_home.php";?>"><input type="button" value="Go Add" style="width:88px;margin-left:5px; background-color:blue; color:white;" class="form-control"/></a>
		</center>
	</div>
	  <?php }?> 
	  <?php if(isset($_SESSION['errprompt']))
	  {?>
	<script> alert("<?php echo $_SESSION['errprompt']; ?>"); </script>
	  <?php }?>
	<div class="table-responsive">
    <table id="stud_data" class="table table-bordered table-striped">
     <thead>
      <tr>
       <th data-column-id="s_no" data-type="numeric">S.No.</th>
       <th data-column-id="sem">Semester</th>
       <th data-column-id="subj_code">Subj Code</th>
       <th data-column-id="subj_name">Paper Name</th>
	   <th data-column-id="credit">Credits</th>
	   <th data-column-id="intrn_mrk">Internal Mark(IA)</th>
	   <th data-column-id="extrn_mrk">External Mark(UE)</th>
	   <th data-column-id="tot_mrk">Total</th>
	   <th data-column-id="grade_pts">Grade Points</th>
	   <th data-column-id="grade">Grade</th>
       <th data-column-id="commands" data-formatter="commands" data-sortable="false">Commands</th>
      </tr>
	  <thead>
	  <?php
	  $id = $_SESSION['userid'];
	  $i = 1;
					$qury1 = "SELECT * FROM student_mark_list WHERE student_id = '$id'";
					$result1 = mysqli_query($con, $qury1);
					while($row = mysqli_fetch_array($result1)):;
				   ?>
      <tr>
        <td><?php echo $i; ?></td>
		<td><?php echo $row[2]; ?></td>
		<td><?php echo $row[3]; ?></td>
		<td><?php echo $row[4]; ?></td>
		<td><?php echo $row[5]; ?></td>
		<td><?php echo $row[6]; ?></td>
		<td><?php echo $row[7]; ?></td>
		<td><?php echo $row[10]; ?></td>
		<td><?php echo $row[8]; ?></td>
		<td><?php echo $row[9]; ?></td>
		<td><a href="student_home.php?id=<?php echo $row[1]; ?>"><input type="button" value="Edit" style="width:88px;margin-left:5px; background-color:red; color:white;"class="form-control"/></a></td>
      </tr>
	  <?php $i++;
	  endwhile; ?>
     </thead>
    </table>
   </div>
   
   <div>
		<center><a href="<?php echo "report.php";?>"><input type="button" value="Submit" style="width:88px;margin-left:5px; background-color:Green; color:white;" class="form-control"/></a>
		</center>
	</div>
<script type="text/javascript" language="javascript">
function chkmrk()
  {
	        var tot = $(total).val();
		    if(tot >= 100){
		    alert("Total Mark should not be greater than 100, Please check your total" );
			return true;
		}
  }
	  
</script>
 
</body>

</html>

<?php
unset($_SESSION['errprompt']);
  mysqli_close($con);

?>
