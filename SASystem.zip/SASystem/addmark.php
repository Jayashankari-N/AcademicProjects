<?php
session_start(); 
require 'connect.php';
require 'functions.php';
$id = $_SESSION['userid'];
if(isset($_POST['addmark']) == 'add') 
{
	$qury1 = "SELECT MAX(slno) FROM student_mark_list WHERE student_id = '$id'";
	$result1 = mysqli_query($con, $qury1);
	while($row = mysqli_fetch_array($result1)):;
	$appl = $row[0];
	endwhile;
	if($appl == null)
	{
		$slno = '1';
	}
	else
	{
		$slno = $appl + 1;
	}
	$sem = clean($_POST['sem']);
	$sub_code = clean($_POST['sub_code']);
	$sub_name = clean($_POST['sub_name']);
	$credit = clean($_POST['credit']);
	$im = clean($_POST['im']);
	$em = clean($_POST['em']);
	$grade_pts = clean($_POST['grade_pts']);
	$grade = clean($_POST['grade']);
	$total = clean($_POST['total']);
	if($sem != '0' && $sub_code != null && $sub_name != '' && $credit != '' && $im != '' && $em != '' && $grade_pts != '' && $grade != '' && $total != '')
	{
		$query = "SELECT * FROM student_mark_list WHERE student_id = '$id'";
		$result = mysqli_query($con,$query);
		if(mysqli_num_rows($result) != null || mysqli_num_rows($result) == null) 
		{
			$mark_insert = "INSERT INTO student_mark_list (student_id,slno,sem,sub_code,sub_name,credit,intrn_mrk,extrn_mrk,grade_pts,grade,total) 
			VALUES ('$id','$slno','$sem','$sub_code','$sub_name','$credit','$im','$em','$grade_pts','$grade','$total')";
			if(mysqli_query($con, $mark_insert)) 
			{
				
			  $_SESSION['prompt'] = " Inserted New Record.";
				header("location:student_home.php");
				exit;
			} 	
			else 
			{

			  die("Error with the query");

			}
		}
		else
		{
			$_SESSION['errprompt'] = "Error";   
			header("location:student_home.php");
			exit;
		}
	}
	else
	{
		 $_SESSION['errprompt'] = "Enter all the field";
		header("location:student_home.php");
		exit;
	}
}
else if(isset($_POST['updatemark']) == 'update')
{
	$slno = clean($_POST['slno']);
	$sem = clean($_POST['sem']);
	$sub_code = clean($_POST['sub_code']);
	$sub_name = clean($_POST['sub_name']);
	$credit = clean($_POST['credit']);
	$im = clean($_POST['im']);
	$em = clean($_POST['em']);
	$grade_pts = clean($_POST['grade_pts']);
	$grade = clean($_POST['grade']);
	$total = clean($_POST['total']);
	if($sem != '0' && $sub_code != null && $sub_name != '' && $credit != '' && $im != '' && $em != '' && $grade_pts != '' && $grade != '' && $total != '')
	{
	
		$query = "SELECT * FROM student_mark_list WHERE student_id = '$id'";
		$result = mysqli_query($con,$query);
		if(mysqli_num_rows($result) != null) 
		{
			$mark_update = "UPDATE student_mark_list SET sem = '$sem', sub_code = '$sub_code', sub_name = '$sub_name', credit='$credit',
			intrn_mrk = '$im', extrn_mrk = '$em', grade_pts = '$grade_pts', grade = '$grade', total = '$total' WHERE student_id = '$id' and slno = '$slno'";
			if(mysqli_query($con, $mark_update)) 
			{
				
			  $_SESSION['prompt'] = " Update Success.";
				header("location:student_home.php");
				exit;
			} 	
			else 
			{

			  die("Error with the query");

			}
		}
		else
		{
			header("location:student_home.php");
			exit;
		}
	}
	else
		{
			$_SESSION['errprompt'] = "Enter all the field";
			header("location:student_home.php");
			exit;
		}
}
session_encode();
mysqli_close($con);

?>