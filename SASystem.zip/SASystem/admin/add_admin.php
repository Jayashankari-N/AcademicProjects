<?php
		
	  require 'connect.php';
	  require 'functions.php';
	  
//insert-add admin	  
if (isset($_POST['signup']))
{
$uname = mysqli_real_escape_string($con, $_POST['username']);
$pword = mysqli_real_escape_string($con, $_POST['password']);
$sql = "INSERT INTO admin_login(username,password) VALUES ('$uname', '$pword')";

if(mysqli_query($con, $sql)){
    header('location:admin_home.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
}
}
// Close connection

mysqli_close($con);
?>
<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Add Admin - Student Admission System</title>

	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/main.css" rel="stylesheet">
</head>
<body>

  

  <section class="center-text">
    
    <strong><font color="green" type ="bold" size=5 >Add Admin</font></strong>
    <div class="login-form box-center clearfix">

    <?php 

        if(isset($_SESSION['prompt'])) {
          showPrompt();
        }

        if(isset($_SESSION['errprompt'])) {
          showError();
        }

      ?>
      <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
        
	 <class="row">
                
              
              <div class="form-group">
                <label for="username">Admin Name  </label>
                <input type="text" class="form-control" name="username" placeholder="User name (must be unique)" required>
              </div>

              <div class="form-group">
                <label for="password">Password  </label>
                <input type="password" class="form-control" name="password" placeholder="Password" maxlength="8" required>
              </div>
			<a href="index.php">Go back</a>
			<input class="btn btn-primary" type="submit" name="signup" value="Sign Up">                    

            

          </div>

</form>
</body>
</html>
