<?php
session_start(); 
require 'connect.php';
require 'functions.php';
$id = $_SESSION['userid'];
if(isset($_POST['updatemark']) == 'update')
{
	$slno = clean($_POST['slno']);
	$sem = clean($_POST['sem']);
	$sub_code = clean($_POST['sub_code']);
	$sub_name = clean($_POST['sub_name']);
	$credit = clean($_POST['credit']);
	$im = clean($_POST['im']);
	$em = clean($_POST['em']);
	$grade_pts = clean($_POST['grade_pts']);
	$grade = clean($_POST['grade']);
	$total = clean($_POST['total']);
	if($sem != '0' && $sub_code != null && $sub_name != '' && $credit != '' && $im != '' && $em != '' && $grade_pts != '' && $grade != '' && $total != '')
	{
	
		$query = "SELECT * FROM student_mark_list WHERE student_id = '$id'";
		$result = mysqli_query($con,$query);
		if(mysqli_num_rows($result) != null) 
		{
			$mark_update = "UPDATE student_mark_list SET sem = '$sem', sub_code = '$sub_code', sub_name = '$sub_name', credit='$credit',
			intrn_mrk = '$im', extrn_mrk = '$em', grade_pts = '$grade_pts', grade = '$grade', total = '$total' WHERE student_id = '$id' and slno = '$slno'";
			if(mysqli_query($con, $mark_update)) 
			{
				
			  $_SESSION['prompt'] = " Update Success.";
				header("location:verify.php");
				exit;
			} 	
			else 
			{

			  die("Error with the query");

			}
		}
		else
		{
			header("location:verify.php");
			exit;
		}
	}
	else
		{
			$_SESSION['errprompt'] = "Enter all the field";
			header("location:verify.php");
			exit;
		}
}
 query5= "SELECT avg(total) FROM stud_mrk_details";
 $result5=mysqli_query($con, $query5); 
 
session_encode();
mysqli_close($con);

?>