<?php
	require 'connect.php';
	require 'functions.php';
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Profile - Student Admission System</title>
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/css/main.css" rel="stylesheet">
	<style>
	.entry_table
	{
		margin-left:30px;
		width:1300px;
		height:70px;
		border: 1px solid black;
		}
	</style>
</head>
<body>
    <?php include 'header1.php'; ?>
	<script src="assets/js/jquery-3.1.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/main.js"></script>
	<?php
 if(isset($_GET['id']))
	  {	?>
	<div style="height:100px;">
	<form action="<?php echo "verify_mark.php";?>" method="post" id="add_mark">
    <table class="entry_table">
      <tr style="border=1px;">
       <td><label style="width:150px;margin-left:5px;">Semester</label></td>
       <td><label style="width:120px;margin-left:5px;">Subject Code</label></td>
       <td><label style="width:180px;margin-left:5px;">Paper Name</label></td>
       <td><label style="width:100px;margin-left:5px;">Credits</label></td>
       <td><label style="width:100px;margin-left:5px;">IA</label></td>
       <td><label style="width:100px;margin-left:5px;">UE</label></td>
       <td><label style="width:100px;margin-left:5px;">Total</label></td>
       <td><label style="width:100px;margin-left:5px;">Grade Points</label></td>
       <td><label style="width:100px;margin-left:5px;">Grade</label></td>
       <td><label style="width:88px;margin-left:5px;">Action</label></td>
      </tr>
