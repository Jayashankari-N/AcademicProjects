<?php 
  require 'connect.php';
  require 'functions.php';
  session_start();
  unset($_SESSION['userid']);
  if(isset($_GET['stid']))
	  {
		  $sid = $_GET['stid'];
		  $_SESSION['userid'] = $sid;
		   header("location:verify.php");
      exit;
	  }
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Profile - Student Admission System</title>
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/css/main.css" rel="stylesheet">
</head>
<body>
    <?php include 'header1.php'; ?>
	<script src="assets/js/jquery-3.1.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/main.js"></script>
	<div class="navbar-brand2">
    <a><h1><span> Student </span> List</h1></a>
		</div>
	<div class="table-responsive" style="width:1200px; margin-left:70px;">
    <table id="stud_data" class="table table-bordered table-striped">
     <thead>
      <tr>
       <th>S.No.</th>
       <th>Student Name</th>
       <th>Admission for</th>
       <th>Date of Birth</th>
	   <th>Gender</th>
	   <th>Caste</th>
	   <th>Address</th>
	   <th>Mobile No</th>
	   <th>Email</th>
       <th>Action</th>
      </tr>
	  <thead>
	  <?php
	  $i = 1;
					$qury1 = "SELECT * FROM student_registration s LEFT JOIN gender g ON s.gender_code = g.gender_code";
					$result1 = mysqli_query($con, $qury1);
					while($row = mysqli_fetch_array($result1)):;
				   ?>
      <tr>
        <td><?php echo $i; ?></td>
		<td><?php echo $row[2]; ?></td>
		<td><?php echo $row[10]; ?></td>
		<td><?php echo $row[5]; ?></td>
		<td><?php echo $row[4]; ?></td>
		<td><?php echo $row[6];?></td>
		<td><?php echo $row[13]; ?></td>
		<td><?php echo $row[15]; ?></td>
		<td><?php echo $row[16]; ?></td>
		<td><a href="<?php echo "admin_home.php?stid=".$row[24];?>"><input type="button" value="Verify" style="width:88px;margin-left:5px; background-color:blue; color:white;"class="form-control"/></a></td>
		 </tr>
	  <?php $i++;
	  endwhile; ?>
     </thead>
    </table>
   </div>
</body>
</html>

<?php
unset($_SESSION['errprompt']);
  mysqli_close($con);

?>
