<?php 
	
	require 'connect.php';
    require 'functions.php';
	session_start();
?>
<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Login - Student Admission System</title>

	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/main.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet" />
</head>
<body>
	<div class="navbar-brand2">
    <a><h1><span>Admin </span>sign in</h1></a>
	
		</div>
    <section class="center-text">
		<div class="login-form box-center">
      <?php 

        if(isset($_SESSION['prompt'])) {
          showPrompt();
        }

        if(isset($_SESSION['errprompt'])) {
          showError();
        }

      ?>
      <form action="<?php echo "login.php"; ?>" method="POST">
        
        <div class="form-group">
          <label for="username" class="sr-only">Username</label>
          <input type="text" class="form-control" name="username" placeholder="Username" required autofocus>
        </div>

        <div class="form-group">
          <label for="password" class="sr-only">Password</label>
          <input type="password" class="form-control" name="password" placeholder="Password" required>
        </div>
        
        <a href="http://localhost/SASystem/index.php">Go back</a>
        <input class="btn btn-primary" type="submit" name="login" value="Log In">

      </form>
    </div>

  </section>


	<script src="assets/js/jquery-3.1.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>

<?php
    unset($_SESSION['prompt']);
	unset($_SESSION['errprompt']);
	session_encode();
  mysqli_close($con);
?>