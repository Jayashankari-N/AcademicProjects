<?php 

	require 'connect.php';
    require 'functions.php';
	session_start();
	$uname = clean($_POST['username']);
	$pword = clean($_POST['password']);
    $query = "SELECT * FROM admin_login WHERE username = '$uname' AND password = '$pword'";
    $result = mysqli_query($con, $query);
    if(mysqli_num_rows($result) > 0) {
      $row = mysqli_fetch_assoc($result);
      $_SESSION['username'] = $row['username'];
      $_SESSION['password'] = $row['password'];
      header("location:admin_home.php");
      exit;
    }
	else
	{
		$_SESSION['errprompt'] = "Invalid Username and Password";
        header("location:index.php");
        exit;
	}
	session_encode();
?>