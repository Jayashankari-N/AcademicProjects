<?php 
  require 'connect.php';
  require 'functions.php';
  session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Profile - Student Admission System</title>

  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/css/main.css" rel="stylesheet">
 <style>
 .profile
 {
	 width:800px;
 }
 .profile table tr
 {
	 height:40px;
 }
 .profile table tr td
 {
	 width:200px;
	 color:#1BBD36;	
	 font-size:16px;
 }
 </style>
</head>
<body>
  <?php include 'header1.php'; ?>

  <section>

  
    <div class="navbar-brand1">
    <a><h1><span>Student </span> Personal Details</h1></a>
</div>
    
    <div class="registration-form box-center clearfix">

      <?php 
	  $id = $_SESSION['userid'];
	  $query = "SELECT * FROM student_registration s 
	  LEFT JOIN gender g ON s.gender_code = g.gender_code 
	  LEFT JOIN community c ON s.community_code = c.community_code 
	  LEFT JOIN religion r ON s.religion_code = r.religion_code 
	  WHERE student_id = '$id'"; 
		 
		  if($result = mysqli_query($con, $query)) {

          $row = mysqli_fetch_assoc($result);
		  
		  ?>
		  <div class="profile">
		  <table>
			<tr>
				<td>STUDENT NAME</td>
				<td><h4><?php echo $row['stu_name']; ?></h4></td>
				<td>GENDER</td>
				<td><h4><?php echo $row['gender_desc']; ?></h4></td>
			</tr>
			<tr>
				<td>DATE OF BIRTH</td>
				<td><h4><?php echo $row['dob']; ?></h4></td>
				<td>COMMUNITY</td>
				<td><h4><?php echo $row['community_desc']; ?></h4></td>
			</tr>
			<tr>
				<td>RELIGION</td>
				<td><h4><?php echo $row['religion_desc']; ?></h4></td>
				<td>NATIONALITY</td>
				<td><h4><?php echo $row['nationality']; ?></h4></td>
			</tr>
			<tr>
				<td>BLOOD GROUP</td>
				<td><h4><?php echo $row['blood_grup']; ?></h4></td>
				<td>DEPARTMENT</td>
				<td><h4><?php echo $row['dept']; ?></h4></td>
			</tr>
			<tr>
				<td>CURRENT ADDRESS</td>
				<td><h4><?php echo $row['cur_address']; ?></h4></td>
				<td>PERMANANT ADDRESS</td>
				<td><h4><?php echo $row['per_address']; ?></h4></td>
			</tr>
			<tr>
				<td>MOBILE NO</td>
				<td><h4><?php echo $row['mobile_no']; ?></h4></td>
				<td>EMAIL ADDRESS</td>
				<td><h4><?php echo $row['email_id']; ?></h4></td>
			</tr>
			
		  </table>
		  </div>
		  
		  <?php
		  }
      ?>
	  </div>

  </section>


	<script src="assets/js/jquery-3.1.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/main.js"></script>
</body>
</html>

<?php


 /* } else {
    header("location:index.php");
    exit;
  }
*/
 // unset($_SESSION['prompt']);
  mysqli_close($con);

?>
