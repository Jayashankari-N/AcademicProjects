<?php 

  session_start();
  require 'connect.php';
  require 'functions.php';
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Register - Student Admission System</title>
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/css/main.css" rel="stylesheet">
</head>
<body>
<?php include 'header.php'; ?>
<div class="navbar-brand1">
    <a><h1><span>Student </span>Registration Form</h1></a>
</div>
<section class="center-text">
    <div class="registration-form box-center clearfix">
    <?php 
        if(isset($_SESSION['errprompt'])) {
          showError();
        }
    ?>
		<form action="<?php echo "registration.php"; ?>" method="POST" id="regform" name="regform">
			<fieldset style="height:50px;">
				<div class="row">
					<div class="col-md-6">                  
						<div class="form-group">
							<label class="col-md-6 control-label" for="lbl_admssn_for">Admission For<span style="color:red;" aria-required="true"> * </span><div  id="coursefor1"></div></label>
							<div class="col-md-6">
								<select class="form-control" name="coursefor" id="coursefor" >
									<option value="0">Select</option>
									<option value="M.sc">M.sc</option>
									<option value="M.phil">M.phil</option>
								</select>
							</div>
						</div>
					</div>
					<div class="col-md-6">       
						<div class="form-group">
							<label class="col-md-6 control-label" for="lbl_dept"> Department/Branch</label>
							<div class="col-md-6">
								<input type="text" class="form-control" name="dept" id="dept" placeholder="Computer Science" value="Computer Science">
							</div>
						</div>
					</div>
				</div>
			</fieldset>
		    <div class="col">
        		<div class="personal-info col-sm-6">
					<fieldset>
            <legend>Personal Info</legend>
			   <div class="form-group">
				
                <label for="firstname">Name<span style="color:red;" aria-required="true"> * </span><div  id="stu_name1"></div></label>
                <input type="text" class="form-control" name="stu_name" id="stu_name" placeholder=" Name">
				
              </div>
			  
			  <div class="form-group">
              <label for="tam_name">Name in Tamil<span style="color:red;" aria-required="true"> * </span><div  id="stu_name_t1"></div></label>
                <input type="text" class="form-control" name="stu_name_t" id="stu_name_t" placeholder="Name in Tamil">
              </div>
			
              <div class="form-group">
                <label for="sex">Gender<span style="color:red;" aria-required="true"> * </span><div  id="gender1"></div></label>
				
                <select class="form-control" name="gender" id="gender">
				  <option value="0">Select</option>
				  <?php
					$qury1 = "SELECT * FROM gender";
					$result1 = mysqli_query($con, $qury1);
					while($row = mysqli_fetch_array($result1)):;
					?>
						<option value = "<?php echo $row[0]; ?>" ><?php echo $row[1]; ?></option>
					<?php endwhile; ?>
                            
                </select>
              </div>
			  
			  <div class="form-group">
                <label for="dob">Date of Birth<span style="color:red;" aria-required="true"> * </span><div  id="dob1"></div></label>
                <input type="Date" class="form-control" name="dob" id="dob" placeholder = "dd-Mon-yyyy">
              </div>
			
			  <div class="form-group">
                <label for="religion">Religion<span style="color:red;" aria-required="true"> * </span><div  id="religion1"></div></label>
                <select class="form-control" name="religion" id="religion">
				  <option value="0">Select</option>
				  <?php
					$qury1 = "SELECT * FROM religion";
					$result1 = mysqli_query($con, $qury1);
					while($row = mysqli_fetch_array($result1)):;
					?>
						<option value = "<?php echo $row[0]; ?>" ><?php echo $row[1]; ?></option>
					<?php endwhile; ?>
                            
                </select></div>

			  <div class="form-group">
                <label for="community">Community<span style="color:red;" aria-required="true"> * </span><div  id="community1"></div></label>
               <select class="form-control" name="community" id="community">
			      <option value="0">Select</option>
                  <?php
					$qury1 = "SELECT * FROM community";
					$result1 = mysqli_query($con, $qury1);
					while($row = mysqli_fetch_array($result1)):;
					?>
						<option value = "<?php echo $row[0]; ?>" ><?php echo $row[1]; ?></option>
					<?php endwhile; ?>
                </select>
              </div>
			  
			  <div class="form-group">
                <label for="nationality">Native State<span style="color:red;" aria-required="true"> * </span><div  id="native_state1"></div></label>
                <input type="text" class="form-control" name="native_state" id="native_state" placeholder="Native State">
              </div>
			  
			  <div class="form-group">
                <label for="nationality">Nationality<span style="color:red;" aria-required="true"> * </span><div  id="nationality1"></div></label>
                <input type="text" class="form-control" name="nationality" id="nationality" placeholder="Nationality">
              </div>

              <div class="form-group">
                <label for="blood_grp">Blood Group<span style="color:red;" aria-required="true"> * </span><div  id="blood_grp1"></div></label>
                <select class="form-control" name="blood_grp" id="blood_grp">
			      <option value="0">Select</option>
                  <?php
					$qury2 = "SELECT * FROM blood_grp";
					$result2 = mysqli_query($con, $qury2);
					while($row = mysqli_fetch_array($result2)):;
					?>
						<option value = "<?php echo $row[0]; ?>" ><?php echo $row[1]; ?></option>
					<?php endwhile; ?>
                </select>
              </div>
			  
			  <div class="form-group">
                <label for="ann_income">Parent's Annual Income:<span style="color:red;" aria-required="true"> * </span><div  id="ann_income1"></div></label>
                <input type="text" class="form-control" name="ann_income" id="ann_income" placeholder="Annual Income In Digits">
              </div>
            </fieldset>
		    </div>
			
		
		<div class="personal-info col-sm-6">
            
           <fieldset>
            <legend>Contact Info</legend>
			
              <div class="form-group">
                <label for="lbl_addr">Address For Communication<span style="color:red;" aria-required="true"> * </span><div  id="cur_add1"></div></label>
                <textarea class="form-control" name="cur_add" id="cur_add" placeholder="Address"></textarea>
              </div>

              <div class="form-group">
                <label for="lbl_addr_perm">Permanent Address<span style="color:red;" aria-required="true"> * </span><div  id="per_add1"></div></label>
                <textarea class="form-control"  name="per_add" id="per_add" placeholder="Permanent Address"></textarea>
              </div>

              <div class="form-group">
                <label for="lbl_mbl_no">Mobile No<span style="color:red;" aria-required="true"> * </span><div  id="mobile1"></div></label>
                <input type="text"  class="form-control" name="mobile" id="mobile" onblur="chkmob1(this);" maxlength="10" autocomplete="off" value="" placeholder="Mobile Number(Valid 10 digit No)">
              </div>

              <div class="form-group">
				<label for="lbl_email">Email<span style="color:red;" aria-required="true"> * </span><div  id="email1"></div></label>
                <input type="text" class="form-control" name="email" value ="" id="email" onblur="ckemail(this);" placeholder="email_id@domain.com" autocomplete="off">  
		      </div>
              
			  <div class="form-group">
                <label for="lbl_addr">A Person of</label>
                <textarea class="form-control" name="person_of" id="person_of" placeholder="A person of" ></textarea>
              </div>
              
            </fieldset>
            </div>
        
		<div class="col">	
		<div class="personal-info col-sm-6">
            
           <fieldset>
            <legend>Academic Details</legend>
			
              <div class="form-group">
                <label for="lbl_yrs_of_study">No. of years of study (School and College)<span style="color:red;" aria-required="true"> * </span><div  id="yrs_of_study1"></div></label>
                <input class="form-control" name="yrs_of_study" id="yrs_of_study" placeholder="Years of Study">
              </div>

              <div class="form-group">
                <label for="lbl_qual_xm_pssd">Qualifying Examination Passed <span style="color:red;" aria-required="true"> * </span><div  id="qual_xm_pssd1"></div></label>
                <input type="text" class="form-control" name="qual_xm_pssd" id="qual_xm_pssd" placeholder="Examination Passed">
              </div>

              <div class="form-group">
                <label for="lbl_qualfication">Qualification<span style="color:red;" aria-required="true"> * </span><div  id="qual1"></div></label>
                <input type="text" class="form-control" name="qual" id="qual" placeholder="Qualification">
              </div>
			  
			  <div class="form-group">
                <label for="lbl_subj">Subject <span style="color:red;" aria-required="true"> * </span><div  id="subj1"></div></label>
                <input type="text" class="form-control" name="subj" id="subj" placeholder="Subject">
              </div>
			  
			  <div class="form-group">
                <label for="lbl_reg_no">Register No.<span style="color:red;" aria-required="true"> * </span><div  id="reg_no1"></div></label>
                <input type="text"  class="form-control" name="reg_no" id="reg_no" placeholder="Your Register Number">
              </div>
			  
			  <div class="form-group">
                <label for="lbl_mon_n_yr_pass">Month and Year of Pass <span style="color:red;" aria-required="true"> * </span><div  id="mon_yr_pass1"></div></label>
                <input type="text" class="form-control" name="mon_yr_pass" id="mon_yr_pass" placeholder="Month - Year">
              </div>
			  <div class="form-group">
                <label for="lbl_mon_n_yr_pass">Student Type<span style="color:red;" aria-required="true"> * </span><div  id="stu_type1"></div></label><br/>
                <!--<select name="stu_type" id="stu_type" class="form-control">
					<option value="0">Select</option>
					<option value="1">Madras University</option>
					<option value="2">Other University</option>
				</select>-->
				<input type="radio" name="stu_type" value="1"><label>University of Madras</label></br>
				<input type="radio" name="stu_type" value="2"><label>Other University</label>
              </div>
            </fieldset>
            </div>	
        </div>
		
			
		
             <div class="account-info col-sm-6">
          
            <fieldset>
                              
			<div class="form-group">
                <label for="lbl_attachments" name="attachments">Submitted Attachments</label>
			</div>
			
			</fieldset>
			</div>
	   
        
        <a href="index.php">Go back</a>
        <input class="btn btn-primary"  id="submit1" type="button" name="register" onclick="f1()" value="Register">



      </form>
    </div>

  </section>


	<script src="assets/js/jquery-3.1.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>

<script src="<?php echo WEB_DIR_NEW;?>assets/pages/tamil/common.js" type="text/javascript"></script>
<script src="<?php echo WEB_DIR_NEW;?>assets/pages/tamil/tamil1.js" type="text/javascript"></script>
<script src="<?php echo WEB_DIR_NEW;?>assets/pages/tamil/tamil.js" type="text/javascript"></script>
<script src="<?php echo WEB_DIR_NEW;?>assets/pages/tamil/converter.js" type="text/javascript"></script>

<script type="text/javascript" language="javascript">


//check required fields
function f1()
    {
		var f = $('#coursefor').val();
		var name = $('#stu_name').val();
		var name_t = $('#stu_name_t').val();
		var gen = $('#gender').val();
		var dob = $('#dob').val();
		var community = $('#community').val();
		var religion = $('#religion').val();
		var native_state=$('#native_state').val();
		var nationality = $('#nationality').val();
		var blood_grp = $('#blood_grp').val();
		var ann_income = $('#ann_income').val();
		var cur_add=$('#cur_add').val();
		var per_add=$('#per_add').val();
		var mobile=$('#mobile').val();
		var email=$('#email').val();
		var yrs_of_study=$('#yrs_of_study').val();
		var qual_xm_pssd=$('#qual_xm_pssd').val();
		var qual=$('#qual').val();
		var subj=$('#subj').val();
		var reg_no=$('#reg_no').val();
		var mon_yr_pass=$('#mon_yr_pass').val();
		var stu_type=$('#stu_type').val();
		
		
		if(f == '0' || name == '' || name_t == '' || gen == '0' || dob == '' || community == '0' || religion == '0' || native_state == '' || nationality == '' || blood_grp == '' || ann_income == '' 
		   || cur_add == '' || per_add == '' || mobile == '' || email == '' || yrs_of_study == '' || qual_xm_pssd == '' || qual =='' || subj == '' || reg_no == ''
		   || mon_yr_pass == '' || stu_type == '')
			{
			var b = ['#coursefor','#stu_name','#stu_name_t','#gender','#dob','#community','#religion','#native_state','#nationality','#blood_grp','#ann_income','#cur_add',
			        '#per_add','#mobile','#email','#yrs_of_study','#qual_xm_pssd','#qual','#subj','#reg_no','#mon_yr_pass','#stu_type'];
			var a = ['#coursefor1','#stu_name1','#stu_name_t1','#gender1','#dob1','#community1','#religion1','#native_state1','#nationality1','#blood_grp1','#ann_income1','#cur_add1',
			        '#per_add1','#mobile1','#email1','#yrs_of_study1','#qual_xm_pssd1','#qual1','#subj1','#reg_no1','#mon_yr_pass1','#stu_type1'];
      		var i;
      		for(i=0;i<b.length;i++)
      		{
        		if($(b[i]).val() == '' || $(b[i]).val() == '0')
        		$(a[i]).html('<span style="color:red;" aria-required="true">Required</span>');
			}
			return false;
		}
		else
		{ 
			document.regform.submit();
			return true;
		} 
    }
	//check for valid email
	function ckemail(email)
	{
		var email = $(email).val();
		var filter = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
		if(email == '')
		{
			return true;
		}
		else if(filter.test(email))
		{
			return true;
		}
		else
		{
			alert("Please check your Email id");
			$(email).parent().addClass('has-error');
			$(email).val('');
			return false;
		}
	}
function chkmob1()
  {
	  var mob = $(mobile).val();
		var first = mob.substring(0,1);
		if(mob == '')
		{
			return true;
		}
		else if(first != 7 && first != 8 && first !=9)
		{
			alert("Invalid mobile number");
			$(mobile).parent().addClass('has-error');
			$(mobile).val('');
			return false;
		}
		else if(mob.length != 10){
			alert("Mobile Number should be 10 digits, Please check your mobile number" );
			$(mobile).parent().addClass('has-error');
			$(mobile).val('');
			return false;
		}
  }
	
	
</script>

<?php 
  unset($_SESSION['errprompt']);
  mysqli_close($con);
?>